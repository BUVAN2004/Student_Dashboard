import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms'; // Import FormsModule
import { MatToolbarModule } from '@angular/material/toolbar'; // Import MatToolbarModule
import { MatFormFieldModule } from '@angular/material/form-field'; // Import MatFormFieldModule
import { MatInputModule } from '@angular/material/input'; // Import MatInputModule
import { MatListModule } from '@angular/material/list'; // Import MatListModule
import { MatButtonModule } from '@angular/material/button'; // Import MatButtonModule

interface Faculty {
  name: string;
  id: string;
  department: string;
  designation: string;
}

interface Student {
  name: string;
  rollNo: string;
}

@Component({
  selector: 'app-markentry',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatToolbarModule,
    MatFormFieldModule,
    MatInputModule,
    MatListModule,
    MatButtonModule,
  ],
  templateUrl: './markentry.component.html',
  styleUrls: ['./markentry.component.css'],
})
export class MarkEntryComponent {
  faculty: Faculty = {
    name: 'John Doe',
    id: 'F12345',
    department: 'Computer Science',
    designation: 'Professor',
  };

  students: Student[] = [
    { name: 'Alice Smith', rollNo: 'CS101' },
    { name: 'Bob Johnson', rollNo: 'CS102' },
    { name: 'Charlie Brown', rollNo: 'CS103' },
  ];

  filteredStudents: Student[] = [];
  searchTerm: string = '';
  selectedStudent: Student | null = null;
  marks: { [key: string]: number | null } = {}; // Allow null values
  subjects: string[] = ['UI/UX', 'DOCUMENT', 'PRESENTATION', 'VIVA', 'WORK FLOW'];

  constructor() {
    this.filteredStudents = this.students;
  }

  filterStudents() {
    this.filteredStudents = this.students.filter(student =>
      student.name.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      student.rollNo.includes(this.searchTerm)
    );
  }

  selectStudent(student: Student) {
    this.selectedStudent = student;
    this.resetMarks();
  }

  resetMarks() {
    this.subjects.forEach(subject => {
      this.marks[subject] = 0; // Initialize with 0 instead of null
    });
  }

  calculateTotal(): number {
    return this.subjects.reduce((total, subject) => total + (this.marks[subject] || 0), 0);
  }

  submitMarks() {
    console.log('Marks submitted for:', this.selectedStudent);
    console.log('Marks:', this.marks);
    // Add your submission logic here
    this.selectedStudent = null; // Reset after submission
  }
}